#include "../Headers/view.h"

View::View() {}

View::~View() {}