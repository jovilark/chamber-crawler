#include "../Headers/tile.h"

Tile::Tile() {}

Tile::~Tile() {}