#include "../Headers/item.h"

Item::Item() {
    setHostile(false);
}

Item::~Item() {}